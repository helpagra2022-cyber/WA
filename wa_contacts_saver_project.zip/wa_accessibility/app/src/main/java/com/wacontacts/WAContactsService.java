package com.wacontacts;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class WAContactsService extends AccessibilityService {

    // WhatsApp aur WhatsApp Business dono ke package names
    private static final String PKG_WA  = "com.whatsapp";
    private static final String PKG_BIZ = "com.whatsapp.w4b";

    // Scroll state
    private boolean isScanning    = false;
    private boolean scrollDone    = false;
    private int     noChangeCount = 0;
    private int     prevCount     = 0;

    // Collected contacts
    private final Set<String>        seen     = new HashSet<>();
    private final List<ContactEntry> contacts = new ArrayList<>();

    // Handler for delayed actions
    private final Handler handler = new Handler(Looper.getMainLooper());

    // Public static so MainActivity can trigger & read
    public static boolean          scanRequested = false;
    public static List<ContactEntry> resultList  = null;
    public static WAContactsService instance     = null;

    @Override
    public void onServiceConnected() {
        instance = this;
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED |
                          AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        info.packageNames = new String[]{PKG_WA, PKG_BIZ};
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS |
                     AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.notificationTimeout = 100;
        setServiceInfo(info);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!scanRequested) return;

        String pkg = event.getPackageName() != null ? event.getPackageName().toString() : "";
        if (!pkg.equals(PKG_WA) && !pkg.equals(PKG_BIZ)) return;

        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.getEventType() == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {

            // Screen content read karo
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) return;

            int before = contacts.size();
            extractContactsFromScreen(root);
            root.recycle();

            if (!isScanning) {
                isScanning = true;
                noChangeCount = 0;
                scheduleScroll();
            }
        }
    }

    // ── Contacts extract karo screen se ──────────────────────────
    private void extractContactsFromScreen(AccessibilityNodeInfo root) {
        // WhatsApp group info mein contacts rows dhundho
        List<AccessibilityNodeInfo> rows = new ArrayList<>();
        findNodes(root, rows);

        for (AccessibilityNodeInfo node : rows) {
            String text = node.getText() != null ? node.getText().toString().trim() : "";
            String desc = node.getContentDescription() != null ? node.getContentDescription().toString().trim() : "";

            String value = text.isEmpty() ? desc : text;
            if (value.isEmpty()) continue;

            // Phone number detect karo
            String cleaned = value.replaceAll("[\\s\\-\\(\\)]", "");
            if (isPhoneNumber(cleaned)) {
                String normalized = normalizePhone(cleaned);
                if (!seen.contains(normalized)) {
                    seen.add(normalized);
                    contacts.add(new ContactEntry(normalized, normalized));
                }
            }
            // Agar name + number dono hain
            else if (value.contains("+") || value.matches(".*\\d{10,}.*")) {
                String num = extractNumber(value);
                if (num != null && !seen.contains(num)) {
                    String name = value.replaceAll("[\\+\\d\\s\\-\\(\\)]+", "").trim();
                    seen.add(num);
                    contacts.add(new ContactEntry(name.isEmpty() ? num : name, num));
                }
            }
        }
    }

    private void findNodes(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        String cls = node.getClassName() != null ? node.getClassName().toString() : "";
        // TextView nodes me actual text hota hai
        if (cls.contains("TextView") || cls.contains("EditText")) {
            out.add(node);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) findNodes(child, out);
        }
    }

    // ── Auto-scroll logic ─────────────────────────────────────────
    private void scheduleScroll() {
        handler.postDelayed(() -> {
            int currentCount = contacts.size();
            if (currentCount == prevCount) {
                noChangeCount++;
            } else {
                noChangeCount = 0;
                prevCount = currentCount;
            }

            // 4 baar scroll ke baad bhi change nahi = done
            if (noChangeCount >= 4) {
                finishScan();
                return;
            }

            performScroll();
            scheduleScroll(); // agli scroll schedule karo
        }, 600); // 600ms interval - WhatsApp ko load hone ka time
    }

    private void performScroll() {
        // Screen ke middle mein swipe up (scroll down)
        int screenH = getResources().getDisplayMetrics().heightPixels;
        int screenW = getResources().getDisplayMetrics().widthPixels;

        Path path = new Path();
        path.moveTo(screenW / 2f, screenH * 0.7f);
        path.lineTo(screenW / 2f, screenH * 0.3f);

        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 300));
        dispatchGesture(builder.build(), null, null);
    }

    // ── Scan complete ─────────────────────────────────────────────
    private void finishScan() {
        isScanning    = false;
        scanRequested = false;
        resultList    = new ArrayList<>(contacts);

        // MainActivity ko notify karo
        Intent intent = new Intent("com.wacontacts.SCAN_COMPLETE");
        intent.putExtra("count", contacts.size());
        sendBroadcast(intent);
    }

    // ── Helpers ───────────────────────────────────────────────────
    private boolean isPhoneNumber(String s) {
        String digits = s.replaceAll("\\D", "");
        return digits.length() >= 10 && digits.length() <= 15 &&
               (s.startsWith("+") || digits.length() == 10 || digits.startsWith("91"));
    }

    private String normalizePhone(String s) {
        String d = s.replaceAll("\\D", "");
        if (d.length() == 10) return "+91" + d;
        if (d.length() == 12 && d.startsWith("91")) return "+" + d;
        return s.startsWith("+") ? s : "+" + d;
    }

    private String extractNumber(String text) {
        java.util.regex.Matcher m = java.util.regex.Pattern
            .compile("(\\+?91[\\s\\-]?)?([6-9]\\d{9})|(\\+\\d{7,14})")
            .matcher(text);
        if (m.find()) return normalizePhone(m.group().replaceAll("[\\s\\-]", ""));
        return null;
    }

    public void startScan() {
        seen.clear();
        contacts.clear();
        resultList    = null;
        scanRequested = true;
        isScanning    = false;
        noChangeCount = 0;
        prevCount     = 0;
    }

    @Override
    public void onInterrupt() {
        instance = null;
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    // Simple contact model
    public static class ContactEntry {
        public String name, phone;
        ContactEntry(String name, String phone) {
            this.name = name; this.phone = phone;
        }
    }
}
