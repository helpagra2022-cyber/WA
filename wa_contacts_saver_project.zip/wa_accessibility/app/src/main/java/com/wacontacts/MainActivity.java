package com.wacontacts;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;
import android.content.ClipData;
import android.content.ClipboardManager;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private TextView  tvStatus, tvCount;
    private Button    btnScan, btnSaveVcf, btnSaveCSV, btnCopy, btnOpenWA, btnOpenWABiz;
    private ListView  lvContacts;
    private LinearLayout llButtons;
    private ProgressBar  progressBar;

    private final BroadcastReceiver scanReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context ctx, Intent intent) {
            onScanComplete();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus    = findViewById(R.id.tvStatus);
        tvCount     = findViewById(R.id.tvCount);
        btnScan     = findViewById(R.id.btnScan);
        btnSaveVcf  = findViewById(R.id.btnSaveVcf);
        btnSaveCSV  = findViewById(R.id.btnSaveCSV);
        btnCopy     = findViewById(R.id.btnCopy);
        btnOpenWA   = findViewById(R.id.btnOpenWA);
        btnOpenWABiz= findViewById(R.id.btnOpenWABiz);
        lvContacts  = findViewById(R.id.lvContacts);
        llButtons   = findViewById(R.id.llButtons);
        progressBar = findViewById(R.id.progressBar);

        llButtons.setVisibility(View.GONE);

        btnScan.setOnClickListener(v -> startScan());
        btnOpenWA.setOnClickListener(v -> openApp("com.whatsapp"));
        btnOpenWABiz.setOnClickListener(v -> openApp("com.whatsapp.w4b"));
        btnSaveVcf.setOnClickListener(v -> saveVCF());
        btnSaveCSV.setOnClickListener(v -> saveCSV());
        btnCopy.setOnClickListener(v -> copyNumbers());

        checkAccessibilityAndUpdate();
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(scanReceiver, new IntentFilter("com.wacontacts.SCAN_COMPLETE"));
        checkAccessibilityAndUpdate();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try { unregisterReceiver(scanReceiver); } catch(Exception ignored) {}
    }

    // ── Accessibility check ───────────────────────────────────────
    private boolean isAccessibilityEnabled() {
        String enabled = "";
        try {
            enabled = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        } catch (Exception ignored) {}
        return enabled != null && enabled.contains("com.wacontacts/.WAContactsService");
    }

    private void checkAccessibilityAndUpdate() {
        if (!isAccessibilityEnabled()) {
            tvStatus.setText("⚠️ Pehle Accessibility permission do");
            btnScan.setText("⚙️ Permission Enable Karo");
            btnScan.setOnClickListener(v -> openAccessibilitySettings());
            btnOpenWA.setVisibility(View.GONE);
            btnOpenWABiz.setVisibility(View.GONE);
        } else {
            tvStatus.setText("✅ Ready! WhatsApp mein Group Info kholo phir Scan dabao");
            btnScan.setText("▶ Scan Shuru Karo");
            btnScan.setOnClickListener(v -> startScan());
            btnOpenWA.setVisibility(View.VISIBLE);
            btnOpenWABiz.setVisibility(View.VISIBLE);
        }
    }

    private void openAccessibilitySettings() {
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        Toast.makeText(this,
            "\"WA Contacts Saver\" dhundho aur ON karo", Toast.LENGTH_LONG).show();
    }

    // ── Scan ──────────────────────────────────────────────────────
    private void startScan() {
        if (!isAccessibilityEnabled()) { openAccessibilitySettings(); return; }
        if (WAContactsService.instance == null) {
            Toast.makeText(this, "Service chal nahi rahi, phone restart karein", Toast.LENGTH_SHORT).show();
            return;
        }

        WAContactsService.instance.startScan();
        progressBar.setVisibility(View.VISIBLE);
        tvStatus.setText("🔄 Scan chal raha hai — WhatsApp Group Info scroll ho raha hai...");
        btnScan.setEnabled(false);
        llButtons.setVisibility(View.GONE);
        lvContacts.setAdapter(null);
        tvCount.setText("");
    }

    private void onScanComplete() {
        progressBar.setVisibility(View.GONE);
        btnScan.setEnabled(true);

        List<WAContactsService.ContactEntry> list = WAContactsService.resultList;
        if (list == null || list.isEmpty()) {
            tvStatus.setText("❌ Koi contact nahi mila. Group Info page par jaao phir dobara try karein.");
            return;
        }

        tvStatus.setText("✅ Scan complete!");
        tvCount.setText(list.size() + " contacts mile");
        llButtons.setVisibility(View.VISIBLE);

        String[] items = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            WAContactsService.ContactEntry c = list.get(i);
            items[i] = c.name.equals(c.phone) ? c.phone : c.name + "  |  " + c.phone;
        }
        lvContacts.setAdapter(new ArrayAdapter<>(this,
            android.R.layout.simple_list_item_1, items));
    }

    // ── Export ────────────────────────────────────────────────────
    private void saveVCF() {
        List<WAContactsService.ContactEntry> list = WAContactsService.resultList;
        if (list == null || list.isEmpty()) return;

        StringBuilder sb = new StringBuilder();
        for (WAContactsService.ContactEntry c : list) {
            sb.append("BEGIN:VCARD\nVERSION:3.0\n")
              .append("FN:").append(c.name.replace("\n","")).append("\n")
              .append("TEL;TYPE=CELL:").append(c.phone).append("\n")
              .append("END:VCARD\n");
        }

        String fname = "wa_contacts_" + stamp() + ".vcf";
        if (writeFile(fname, sb.toString())) {
            Toast.makeText(this,
                "✅ VCF saved: " + fname + "\nDownloads folder mein hai — tap karke import karo",
                Toast.LENGTH_LONG).show();
        }
    }

    private void saveCSV() {
        List<WAContactsService.ContactEntry> list = WAContactsService.resultList;
        if (list == null || list.isEmpty()) return;

        StringBuilder sb = new StringBuilder("Name,Phone\n");
        for (WAContactsService.ContactEntry c : list) {
            sb.append('"').append(c.name.replace("\"","'")).append('"')
              .append(',').append(c.phone).append('\n');
        }

        String fname = "wa_contacts_" + stamp() + ".csv";
        if (writeFile(fname, sb.toString())) {
            Toast.makeText(this, "✅ CSV saved: " + fname, Toast.LENGTH_SHORT).show();
        }
    }

    private void copyNumbers() {
        List<WAContactsService.ContactEntry> list = WAContactsService.resultList;
        if (list == null || list.isEmpty()) return;

        StringBuilder sb = new StringBuilder();
        for (WAContactsService.ContactEntry c : list) sb.append(c.phone).append("\n");

        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("wa_numbers", sb.toString().trim()));
        Toast.makeText(this, "📋 " + list.size() + " numbers copy ho gaye!", Toast.LENGTH_SHORT).show();
    }

    private boolean writeFile(String name, String content) {
        try {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File f = new File(dir, name);
            FileWriter fw = new FileWriter(f);
            fw.write(content);
            fw.close();
            return true;
        } catch (IOException e) {
            Toast.makeText(this, "Save error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private void openApp(String pkg) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i != null) startActivity(i);
        else Toast.makeText(this, pkg + " install nahi hai", Toast.LENGTH_SHORT).show();
    }

    private String stamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(new Date());
    }
}
