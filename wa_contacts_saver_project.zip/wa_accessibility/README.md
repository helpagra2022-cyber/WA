# WA Group Contacts Saver

WhatsApp aur WhatsApp Business ke group members ko auto-scroll karke contacts extract karne wala Android app.

---

## Build Kaise Karein (Android Studio se)

### Option A — Android Studio (Recommended)
1. Android Studio download karo: https://developer.android.com/studio
2. Ye poora folder (`WAContactsSaver`) Android Studio mein open karo
3. Top mein **Build → Build APK** click karo
4. `app/build/outputs/apk/debug/app-debug.apk` milega
5. Apne phone pe copy karo aur install karo

### Option B — Online (Bina PC ke)
1. https://www.jdoodle.com ya https://appetize.io — limited support
2. **Best online option:** GitHub Actions se build (free):
   - GitHub pe account banao
   - Is folder ko upload karo
   - `.github/workflows/build.yml` add karo (neeche diya hai)
   - Automatically APK ban jaayega

### GitHub Actions Workflow (`.github/workflows/build.yml`):
```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with:
          java-version: '17'
          distribution: 'temurin'
      - name: Build APK
        run: |
          chmod +x gradlew
          ./gradlew assembleDebug
      - uses: actions/upload-artifact@v3
        with:
          name: app-debug
          path: app/build/outputs/apk/debug/app-debug.apk
```

---

## Phone pe Install Kaise Karein

1. Settings → Security → **Unknown Sources** ON karo
2. APK file tap karo → Install
3. App open karo

---

## App Use Karna

1. App pehli baar kholne par **"Permission Enable Karo"** dikhega
2. Tap karo → Accessibility Settings khulengi
3. **"WA Contacts Saver"** dhundho → ON karo → Wapas aao
4. App mein **"WhatsApp Kholo"** ya **"WA Business Kholo"** button dabao
5. Group kholo → Group naam tap karo → Members list dikhne do
6. App par wapas aao → **"▶ Scan Shuru Karo"** dabao
7. App apne aap WhatsApp pe jaayega, scroll karega, contacts read karega
8. Done hone par:
   - **📱 VCF Save** → Downloads mein save hoga → tap karke import karo
   - **📊 CSV Save** → Spreadsheet ke liye
   - **📋 Numbers Copy** → Clipboard mein

---

## Zaruri Baatein

- **Accessibility Service sirf local kaam karta hai** — koi data bahar nahi jaata
- WhatsApp 2024+ mein kuch phones pe screen reading restrict ho sakti hai
- Agar numbers nahi mil rahe toh Group Info page pe manually thoda scroll karo phir scan karo
